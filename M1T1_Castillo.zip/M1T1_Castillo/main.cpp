//This is an orientation assignment program
//January 10, 2022
//CSC-234-0901
//Zachary Castillo

#include <iostream>

using namespace std;

int main()
{
    cout << "Hello my name is Zachary Castillo." << endl;
    cout << "I am currently studying Advanced python as well as this advanced C++ course." << endl;
    cout << "In my free time I enjoy spending time with my kids and working out." << endl;

    return 0;
}
