//This program runs a simple game of Rock Paper Scissors against the computer
//January 31, 2022
//CSC-234-0901
//Zachary Castillo

#include <iostream>
//Declares constant integers for the main program
const int rock = 1;
const int Paper = 2;
const int scissors = 3;

using namespace std;
int main()
{
// Gets random choice from the computer
int compChoice = rand() % 3 + 1;
//Gets user choice and displays the menu
int userChoice;
cout << "Lets play a game!" << endl;
cout << "Please select a number to make your choice." << endl;
cout << "(1) for Rock" << endl << "(2) for paper" << endl << "(3) for Scissors" << endl;
cin >> userChoice;
//Tells user to enter a valid choice if a proper choice is not chosen
while (userChoice!= 1 && userChoice!=2 && userChoice!=3){
    cout << "Please enter a valid option" << endl;
    cout << "(1) for Rock" << endl << "(2) for paper" << endl << "(3) for Scissors" << endl;
    cin >> userChoice;
}
//Displays the computer and user choice
cout << "You chose: " << userChoice << endl;
cout << "Computer chose: " << compChoice << endl;
//Compares the user choice to the computer choice to declare a winner or tie
if((userChoice == 1) && (compChoice == 2)|| (userChoice == 2) && (compChoice == 3)||(userChoice) == 3 && (compChoice == 1)){
     cout << "Computer Wins" << endl;
}
else if ((userChoice == 1) && (compChoice == 3)||(userChoice == 2) && (compChoice == 1)||(userChoice == 3) && (compChoice == 2)){
    cout << "You Win!" << endl;
}
else{
    cout << "It was a tie" << endl;
}
return 0;
}


